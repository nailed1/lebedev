﻿#include <iostream>
using namespace std;
int main()
{
	int a, b, c;
	cout << "Enter a, b, c: ";
	cin >> a >> b >> c;
	double x = -b / (2.0 * a);
	double y = a * (x * x) + b * x + c;
	cout << "y: " << y << endl;
	return 0;
}