﻿#include <iostream>
using namespace std;
int main()
{
	int h, m, s;
	cout << "Enter h, m, s: ";
	cin >> h >> m >> s;
	int s1 = (s + 29) / 60;
	int m1 = m + s1;
	cout << "hours, minutes: " << h << m1 << endl;
	int m2 = (m1 + 29) / 60;
	int h1 = h + m2;
	cout << "hours: " << h1 << endl;
}