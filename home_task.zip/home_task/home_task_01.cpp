﻿#include <iostream>
using namespace std;
int main(void)
{
	int d, m, s;
	cout << "enter degree, minute, second: ";
	cin >> d >> m >> s;
	double grd, r;
	grd = d + (m / 60.0) + (s / 3600.0);
	double p = 3.141592653589793;
	r = grd * p / 180;
	cout << "rad:" << r << endl;

	return 0;
}