﻿#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	double k, p, s;
	cout << "enter k p s ";
	cin >> k >> p >> s;
	double mnths;
	mnths = log(s / k) / log(1 + p / 100);
	double yrs = mnths / 12;
	cout << "years: " << yrs << endl;
	return 0;
}