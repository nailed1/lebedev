﻿#include <iostream>
using namespace std;
int main()
{
	double r;
	cout << "Enter rad ";
	cin >> r;
	double p = 3.141592653589793;
	double gr = r*180/p;

	double d = int(gr);
	double lft = gr-d;

	double m = int(lft*60);
	lft = lft*60-m;

	double s = lft * 60;
	cout << "degree: " << d << " minute: " << m << " second: " << s << endl;

	return 0;
}